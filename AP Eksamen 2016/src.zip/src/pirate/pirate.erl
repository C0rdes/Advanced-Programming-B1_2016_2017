-module(pirate).
-export([go_on_account/0, register_simple/3, register_command/4, mission/2, ahoy/1]).


go_on_account() ->
    undefined.

register_simple(_, _, _) ->
    undefined.
  
register_command(_, _, _, _) ->
    undefined.

mission(_, _) ->
    undefined.

ahoy(_) ->
    undefined.
    
