module Interp
  ( build
  , replace
  , match
  , check
  ) where

import Interp.Impl
